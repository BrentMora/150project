{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE DeriveGeneric #-}

module Main where

import Network.WebSockets
import Control.Concurrent (forkIO)
import Control.Monad (forever)
import Data.Aeson (decode, encode)
import qualified Data.Text.Lazy.Encoding as TL
import qualified Data.Text.Lazy as TL
import Game

main :: IO ()
main = do
  putStrLn "Starting server on port 9160"
  runServer "127.0.0.1" 9160 application

-- Accept a new client
application :: ServerApp
application pending = do
  conn <- acceptRequest pending
  putStrLn "Client connected"
  -- fork a new thread per client
  forkIO $ clientLoop conn (Player 50 50)
  return ()

-- Main loop per client
clientLoop :: Connection -> Player -> IO ()
clientLoop conn player = do
  -- send initial state
  sendTextData conn (encode (State player))
  forever $ do
    msgData <- receiveData conn
    case decode msgData :: Maybe Msg of
      Just MoveUp    -> sendNewState conn player (0, -10)
      Just MoveDown  -> sendNewState conn player (0, 10)
      Just MoveLeft  -> sendNewState conn player (-10, 0)
      Just MoveRight -> sendNewState conn player (10, 0)
      _              -> return ()

-- Update player state and send it
sendNewState :: Connection -> Player -> (Int, Int) -> IO ()
sendNewState conn (Player x y) (dx, dy) = do
  let newPlayer = Player (x + dx) (y + dy)
  sendTextData conn (encode (State newPlayer))
