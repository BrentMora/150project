{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE OverloadedStrings #-}

module Game where

import GHC.Generics (Generic)
import Data.Aeson (ToJSON, FromJSON)

-- Player position
data Player = Player
  { px :: Int
  , py :: Int
  } deriving (Show, Generic)

instance ToJSON Player
instance FromJSON Player

-- Messages between client and server
data Msg
  = MoveUp
  | MoveDown
  | MoveLeft
  | MoveRight
  | State Player
  deriving (Show, Generic)

instance ToJSON Msg
instance FromJSON Msg
