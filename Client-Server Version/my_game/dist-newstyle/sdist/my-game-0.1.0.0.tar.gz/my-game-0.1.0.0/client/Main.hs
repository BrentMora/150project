{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RecordWildCards #-}
{-# LANGUAGE DeriveGeneric #-}

module Main where

import Miso
import Miso.String (ms)
import Miso.Events (onClick)
import Miso.Subscription.WebSocket (webSocketSub)
import Data.Aeson (decode, encode)
import Game
import Data.Text.Lazy.Encoding (encodeUtf8)
import qualified Data.Text.Lazy as TL

-- Model
data Model = Model
  { player :: Player
  } deriving (Eq)

-- Actions
data Action
  = NoOp
  | WSMsg Msg
  | SendMove Msg
  deriving (Show, Eq)

-- Initial model
initialModel :: Model
initialModel = Model (Player 50 50)

-- Update function
updateModel :: Action -> Model -> Effect Action Model
updateModel NoOp m = noEff m
updateModel (WSMsg (State p)) m = noEff m { player = p }
updateModel (SendMove mv) m =
  m <# do
    -- Send move message to server via JS WebSocket
    jsSendMove (encode mv)
    pure NoOp

-- View function
viewModel :: Model -> View Action
viewModel Model{..} =
  div_ []
    [ div_ []
        [ button_ [ onClick (SendMove MoveUp) ] [ text "Up" ]
        , button_ [ onClick (SendMove MoveDown) ] [ text "Down" ]
        , button_ [ onClick (SendMove MoveLeft) ] [ text "Left" ]
        , button_ [ onClick (SendMove MoveRight) ] [ text "Right" ]
        ]
    , canvas_ [ width_ 400, height_ 400, style_ [("border", "1px solid black")] ] [ renderPlayer player ]
    , div_ [] [ text $ ms ("Player at: " ++ show (px player, py player)) ]
    ]

-- Canvas rendering
renderPlayer :: Player -> View action
renderPlayer Player{..} =
  svg_ [ width_ "400", height_ "400" ] 
    [ rect_ [ x_ (ms $ show px)
            , y_ (ms $ show py)
            , width_ "20"
            , height_ "20"
            , fill_ "blue"
            ] []
    ]

-- WebSocket subscription
subscriptions :: Model -> Sub Action
subscriptions _ = webSocketSub "ws://127.0.0.1:9160" $ \msg ->
  case decode msg of
    Just gameMsg -> WSMsg gameMsg
    Nothing -> NoOp

-- Main entry point
main :: IO ()
main = startApp App
  { initialAction = NoOp
  , model  = initialModel
  , update = updateModel
  , view   = viewModel
  , events = defaultEvents
  , subs   = subscriptions
  , mountPoint = Nothing
  }

-- JS FFI to send messages to WebSocket
foreign import javascript unsafe
  "window.clientSocket && window.clientSocket.send($1)"
  jsSendMove :: TL.Text -> IO ()
